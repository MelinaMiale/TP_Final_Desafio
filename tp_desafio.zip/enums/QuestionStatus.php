<?php

class QuestionStatus
{
    const APPROVED = 1;
    const PENDING = 2;
    const REJECTED = 3;
}