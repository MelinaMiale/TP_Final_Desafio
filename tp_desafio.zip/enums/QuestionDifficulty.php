<?php

class QuestionDifficulty {
    const EASY = 1;
    const MEDIUM = 2;
    const HARD = 3;
}