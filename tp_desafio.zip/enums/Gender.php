<?php

class Gender {
    const FEMALE = 1;
    const MALE = 2;
    const UNSPECIFIED = 3;

}