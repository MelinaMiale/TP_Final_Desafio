<?php
class Role {
    const ADMIN = 1;
    const EDITOR = 2;
    const PLAYER = 3;
}
