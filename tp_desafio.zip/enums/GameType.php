<?php

class GameType {
    const VS_BOT = 1;
    const VS_PLAYER = 2;
}