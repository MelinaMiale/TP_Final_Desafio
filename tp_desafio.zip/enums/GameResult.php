<?php

class GameResult {
    const WON = 1;
    const LOST = 2;

}