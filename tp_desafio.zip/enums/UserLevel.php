<?php
class UserLevel {
    const LOW_KI = 1;
    const WARRIOR = 2;
    const SUPER_SAYAYIN = 3;
}